H5_file_name = '/Users/phil/Dropbox/Autocurator/testing_data/MP4s/AH0698x170601_PHIL/AH0698x170601-.h5'
label_key = 'labels'



from whacc.touch_curation_GUI import touch_gui

touch_gui(H5_file_name, label_key, 'new_labels')
'''test
H5_file_name
to see if it has new labels '''
